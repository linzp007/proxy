

#include<iostream>
#include<iomanip>
#include"quadtreepath.h"
#include "tree_utils.h"
#include "quadtree_utils.h"
using namespace std;
// using namespace qtpacket;

std::uint8_t children[] = { 
	0x4f, 0x4f, 0x4c, 0x10, 0x10, 0x44, 0x10, 0xef,
	0x70, 0x70, 0x70, 0x70, 0xef, 0x70, 0x70, 0x70, 
	0x70, 0x4f, 0x4c, 0x10, 0x10, 0x4c, 0x10, 0x10,
	0xef, 0x70, 0x70, 0x70, 0x70, 0xef, 0x70, 0x70, 
	0x70, 0x70, 0x4f, 0xef, 0x70, 0x70, 0x70, 0x70, 
	0xef, 0x70, 0x70, 0x70, 0x70, 0x40, 0x40, 0x4f, 0xef, 
	0x70, 0x70, 0x70, 0x70, 0xef, 0x70, 0x70, 0x70, 
	0x70, 0x40, 0x48, 0x10};

const std::uint8_t bytemaskBTG[] = {
	0x01, 0x02, 0x04, 0x08, 0x10, 0x20, 0x40, 0x80
};

static qtpacket::QuadtreeNumbering tree_numbering(5, true);
static qtpacket::QuadtreeNumbering root_numbering(4, false);

int  GetBit(std::uint8_t children, int bit) {
	
	return (children & bytemaskBTG[bit]) != 0; 
}

void Traverser(
	const qtpacket::QuadtreeNumbering &numbering,
	int *node_indexp,
	const QuadtreePath &qt_path, int number_instances) {
	cout << endl << endl << endl;
	cout << "Traverser index ============================================== " << *node_indexp << endl;
	if (*node_indexp >= number_instances) {
		cout << "Travel end, node index > number instances " << endl;
		return;
    }

	// const KhQuadTreeQuantum16* node = GetPtr(*node_indexp);
	int subindex =
		numbering.InorderToSubindex(numbering.TraversalPathToInorder(qt_path));
	 // collector->Collect(*node_indexp, qt_path, subindex, node);
	std::cout << "                                                          node_indexp: " << *node_indexp << " qt_path: " << qt_path.AsString() << " subindex: " << subindex << endl;
	// Descend to children, using children bits in the packet
	for (int i = 0; i < 4; ++i) {
		cout << "## children::  " << hex << (int)children[*node_indexp] << " GetBit :: " << *node_indexp << " bit: " << i << " result : " << GetBit(children[*node_indexp], i) << endl;
		if (GetBit(children[*node_indexp], i)) {
			const QuadtreePath new_qt_path(qt_path.Child(i));
			*node_indexp += 1;
			cout << "i = " << i << "    " <<" start sub traversal node index : " << *node_indexp << " new path :" << new_qt_path.AsString() << endl;
			Traverser(numbering, node_indexp, new_qt_path, number_instances);
		}
		/*
		else {
			cout << "=================================> node_indexp : " << *node_indexp << "i = " << i << " Get bit false :" << *node_indexp << endl;
		}
		*/
	}
}




void toString(bool root_node, bool detailed_info) {
	int node_index = 0;
	Traverser(root_node ? root_numbering : tree_numbering, &node_index, QuadtreePath(), 61);
}

int main() {
	
	qtpacket::TreeNumbering tn(4, 5, false);
	cout << tn.TraversalPathToInorder("020") << endl;
	cout << tn.TraversalPathToSubindex("020") << endl;
	cout << tn.SubindexToTraversalPath(29).AsString() << endl;
	cout << tn.InorderToSubindex(8) << endl;

	cout << tn.TraversalPathToInorder("022") << endl;
	cout << tn.TraversalPathToSubindex("022") << endl;
	cout << tn.SubindexToTraversalPath(31).AsString() << endl;
	cout << tn.InorderToSubindex(10) << endl;

	cout << "------------------------------------------------" << endl;

	qtpacket::QuadtreeNumbering qn(5, false);

	cout << qn.NumNodes(3) << endl;

	QuadtreePath qp("022");
	cout << qp.Level() << endl;
	cout << qn.TraversalPathToGlobalNodeNumber(qp) << endl;
	cout << qn.TraversalPathToInorder(qp) << endl;

	int subindex =
		qn.InorderToSubindex(qn.TraversalPathToInorder("002"));
	cout << "subindex -> " << subindex << endl;


	cout << "------------------------------------------------" << endl;
	toString(true, false);

	system("pause");
	return 0;
}