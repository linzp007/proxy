

#include<iostream>
#include<iomanip>
#include"quadtreepath.h"
#include "tree_utils.h"
#include "quadtree_utils.h"
using namespace std;
// using namespace qtpacket;

std::uint8_t children[] = { 
	0x4f, 0x4f, 0x4c, 0x10, 0x10, 0x44, 0x10, 0xef,
	0x70, 0x70, 0x70, 0x70, 0xef, 0x70, 0x70, 0x70, 
	0x70, 0x4f, 0x4c, 0x10, 0x10, 0x4c, 0x10, 0x10,
	0xef, 0x70, 0x70, 0x70, 0x70, 0xef, 0x70, 0x70, 
	0x70, 0x70, 0x4f, 0xef, 0x70, 0x70, 0x70, 0x70, 
	0xef, 0x70, 0x70, 0x70, 0x70, 0x40, 0x40, 0x4f, 0xef, 
	0x70, 0x70, 0x70, 0x70, 0xef, 0x70, 0x70, 0x70, 
	0x70, 0x40, 0x48, 0x10};

const std::uint8_t bytemaskBTG[] = {
	0x01, 0x02, 0x04, 0x08, 0x10, 0x20, 0x40, 0x80
};

static qtpacket::QuadtreeNumbering tree_numbering(5, true);
static qtpacket::QuadtreeNumbering root_numbering(4, false);

int  GetBit(std::uint8_t children, int bit) {
	
	return (children & bytemaskBTG[bit]) != 0; 
}

void Traverser(
	const qtpacket::QuadtreeNumbering &numbering,
	int *node_indexp,
	const QuadtreePath &qt_path, int number_instances) {
	cout << endl << endl << endl;
	if (*node_indexp >= number_instances) {
		cout << "Travel end, node index > number instances " << endl;
		return;
    }

	std::uint8_t child = children[*node_indexp];

	// const KhQuadTreeQuantum16* node = GetPtr(*node_indexp);
	int subindex =
		numbering.InorderToSubindex(numbering.TraversalPathToInorder(qt_path));
	 // collector->Collect(*node_indexp, qt_path, subindex, node);
	std::cout << "node_indexp: " << *node_indexp << " qt_path: " << qt_path.AsString() << " subindex: " << *dec << subindex << endl;
	// Descend to children, using children bits in the packet
	for (int i = 0; i < 4; ++i) {
		if (GetBit(child, i)) {
			const QuadtreePath c = qt_path.Child(i);
			cout << c.AsString() << endl;
			const QuadtreePath new_qt_path(qt_path.Child(i));
			*node_indexp += 1;
			Traverser(numbering, node_indexp, new_qt_path, number_instances);
		}
	}
}




void toString(bool root_node, bool detailed_info) {
	int node_index = 0;
	Traverser(root_node ? root_numbering : tree_numbering, &node_index, QuadtreePath(), 61);
}

int main() {
	
	/*
	qtpacket::TreeNumbering tn(4, 5, false);
	cout << tn.TraversalPathToInorder("020") << endl;
	cout << tn.TraversalPathToSubindex("020") << endl;
	cout << tn.SubindexToTraversalPath(29).AsString() << endl;
	cout << tn.InorderToSubindex(8) << endl;

	cout << tn.TraversalPathToInorder("022") << endl;
	cout << tn.TraversalPathToSubindex("022") << endl;
	cout << tn.SubindexToTraversalPath(31).AsString() << endl;
	cout << tn.InorderToSubindex(10) << endl;

	cout << "------------------------------------------------" << endl;
	
	qtpacket::QuadtreeNumbering qn(5, false);

	cout << qn.NumNodes(3) << endl;

	cc
	cout << qp.Level() << endl;
	cout << qn.TraversalPathToGlobalNodeNumber(qp) << endl;
	cout << qn.TraversalPathToInorder(qp) << endl;

	int subindex =
		qn.InorderToSubindex(qn.TraversalPathToInorder("002"));
	cout << "subindex -> " << subindex << endl;

	*/
	

	/*
	cout << "------------------------------------------------" << endl;
	toString(true, false);
	*/

	/*
	QuadtreePath qp("0");
	cout << qp.Child(0).Level() << endl;
	*/


	system("pause");
	return 0;
}